
#ifndef EXPLOSION_H
#define EXPLOSION_H

void drawExplosion(float *spire_radius);

#endif /* EXPLOSION_H */
