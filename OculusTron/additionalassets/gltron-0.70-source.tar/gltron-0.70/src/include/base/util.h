#ifndef UTIL_H
#define UTIL_H

void runScript(int ePath, const char *name);

#endif
