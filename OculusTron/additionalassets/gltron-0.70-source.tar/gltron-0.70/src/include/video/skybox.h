#ifndef SKYBOX_H
#define SKYBOX_H

void enableSkyboxTexture(void);
void disableSkyboxTexture(void);
void drawSkybox(int grid_size);

#endif /* SKYBOX_H */


