#ifndef NEBU_RANDOM_H
#define NEBU_RANDOM_H

void tsrand(unsigned int s);
int trand(void);
double tfrand(void);

#endif
