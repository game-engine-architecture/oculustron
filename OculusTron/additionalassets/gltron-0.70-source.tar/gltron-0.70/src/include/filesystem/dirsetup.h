#ifndef DIRSETUP_H
#define DIRESTUP_H

#include "path.h"

void dirSetup(const char *executable);
const char* getHome(void);

#endif
