#ifndef _NEBU_H
#define _NEBU_H

#include "Nebu_base.h"
#include "Nebu_filesystem.h"
#include "Nebu_scripting.h"
#include "Nebu_configuration.h"
#include "Nebu_video.h"
#include "Nebu_input.h"

#endif
