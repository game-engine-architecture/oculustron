#ifndef TIMESYSTEM_H
#define TIMESYSTEM_H

void Time_Idle(void);

#endif
