#ifndef _NEBU_SCRIPTING_H
#define _NEBU_SCRIPTING_H

#include "scripting/nebu_scripting.h"

#endif
