#ifndef SCRIPTING_H
#define SCRIPTING_H

extern void init_c_interface(void);

#endif
