#ifndef _NEBU_INPUT_H
#define _NEBU_INPUT_H

#include "input/nebu_input_system.h"
#include "input/nebu_system_keynames.h"

#endif
